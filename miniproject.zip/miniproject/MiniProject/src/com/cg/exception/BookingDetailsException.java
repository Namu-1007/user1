package com.cg.exception;

public class BookingDetailsException extends Exception
{
	public BookingDetailsException(String msg)
	{
		super(msg);
	}
}
