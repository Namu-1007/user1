package com.cg.dao;

import java.sql.*;
import java.util.ArrayList;

import com.cg.bean.BookingDetails;
import com.cg.exception.BookingDetailsException;
import com.cg.util.DBUtil;

public class BookingDetailsDaoImpl implements BookingDetailsDao
{
	Connection con=null;
	Statement st=null;
	ResultSet rs=null;

	@Override
	public ArrayList<BookingDetails> getAllDetails() throws BookingDetailsException 
	{
		ArrayList<BookingDetails> bookingList=new ArrayList<BookingDetails>();
		String selectQry="SELECT * FROM BookingDetails";
		BookingDetails bk;
		
		try {			
				con=DBUtil.getCon();
				st=con.createStatement();
				rs=st.executeQuery(selectQry);
				while(rs.next())
				{
					bk=new BookingDetails (rs.getInt("booking_id"),
							rs.getInt("room_id"),rs.getInt("user_id"),
							rs.getDate("booked_from"), rs.getDate("booked_to"), rs.getInt("no_of_adults"),
							rs.getInt("no_of_children"),rs.getFloat("amount"));
					bookingList.add(bk);
				}
			} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (Exception e) 
			{
				throw new BookingDetailsException(e.getMessage());				
			}
		}
		return bookingList;
	}
}

		
	
	
	

