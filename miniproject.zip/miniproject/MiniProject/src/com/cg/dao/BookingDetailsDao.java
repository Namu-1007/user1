package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.BookingDetails;
import com.cg.exception.BookingDetailsException;

public interface BookingDetailsDao
{
	public ArrayList<BookingDetails> getAllDetails() throws BookingDetailsException;
}
