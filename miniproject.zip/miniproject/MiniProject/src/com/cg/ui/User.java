package com.cg.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.BookingDetails;
import com.cg.exception.BookingDetailsException;
import com.cg.service.BookingDetailsService;
import com.cg.service.BookingDetailsServiceImpl;

public class User 
{
	static Scanner sc=null;
	static BookingDetailsService bookSer=null;
	
	
	public static void main(String[] args) 
	{
		bookSer=new BookingDetailsServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		
		while(true)
		{
			System.out.println("What do u want to do?");
			System.out.println("1. Fetch details of all mobiles available in the shop\n"							  							
							  +"2. Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	fetchAllBookingDetails();
					break;
			case 2:	System.exit(0);
					break;	
			default: System.out.println("Invalid Choice");
			}
			
		}
	}
	//***************************main ends here********************************
		private static void fetchAllBookingDetails() 
		{
			try 
			{
				ArrayList<BookingDetails> bookList=bookSer.getAllMob();
				for(BookingDetails bk:bookList) 
				{
					System.out.println(bk);
				}
			} 
			catch (BookingDetailsException e)
			{
				System.out.println("Some exception while fetching data");
				e.printStackTrace();
			}
			
		}
		
}

