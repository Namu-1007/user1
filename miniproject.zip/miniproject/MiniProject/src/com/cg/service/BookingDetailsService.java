package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.BookingDetails;

import com.cg.exception.BookingDetailsException;

public interface BookingDetailsService 
{
	public ArrayList<BookingDetails> getAllMob() throws BookingDetailsException; 		
}
