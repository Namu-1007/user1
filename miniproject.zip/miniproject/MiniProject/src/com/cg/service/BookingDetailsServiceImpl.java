package com.cg.service;

import java.util.ArrayList;
import com.cg.bean.BookingDetails;
import com.cg.dao.BookingDetailsDao;
import com.cg.dao.BookingDetailsDaoImpl;
import com.cg.exception.BookingDetailsException;


public class BookingDetailsServiceImpl implements BookingDetailsService
{
	BookingDetailsDao bookDao=null;
	public BookingDetailsServiceImpl()
	{
		bookDao=new BookingDetailsDaoImpl();
	}
	
	@Override
	public ArrayList<BookingDetails> getAllMob() throws BookingDetailsException
	{
	
		return bookDao.getAllDetails();
	}
	
}

